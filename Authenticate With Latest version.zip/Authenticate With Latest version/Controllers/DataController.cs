﻿using Authenticate_With_Latest_version.Models.Pagination;
using Authenticate_With_Latest_version.Services.Pagination;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Authenticate_With_Latest_version.Controllers
{
    [ApiController]
    public class DataController : ControllerBase
    {
        private IMockData _mockData;
        public DataController(IMockData mockData)
        {
            _mockData = mockData;
        }
        [Route("api/{controller}/{action}")]
        [HttpGet]
        public async Task<ActionResult<List<MockDataDto>>> GetMockData([FromBody] Page page)
        {
            PagedList<MockDataDto> mockData = await _mockData.GetMockDataPagedAsync(page);
            Response.Headers.Add("X-Pagination", JsonConvert.SerializeObject(mockData.PagedListMetaData));
            return Ok(mockData);
        }
    }
}
