﻿using Authenticate_With_Latest_version.Models;
using Authenticate_With_Latest_version.Response;
using Authenticate_With_Latest_version.Services.ProfileServices;
using Microsoft.AspNet.Identity;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.IO;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Authenticate_With_Latest_version.Controllers
{
    [Route("api/{controller}")]
    [ApiController]
    [Authorize]
    public class ProfileImageController : ControllerBase
    {
        private readonly ProfileServices _repository;
        public string user_Id;
        public ProfileImageController(ProfileServices repository)
        {
            this._repository = repository ?? throw new ArgumentNullException(nameof(repository));
        }
        
        [HttpPost]
        public async Task<DeptResponse> insertImg([FromForm] ImageUpload value)
        {          
            try
            {
                var files = HttpContext.Request.Form.Files;
                if (files != null && files.Count > 0)
                {
                    foreach (var file in files)
                    {
                        FileInfo fileInfo = new FileInfo(file.FileName);
                        var date = DateTime.Now;
                        var newfilename = "Image_" + DateTime.Now.Millisecond + fileInfo.Extension;
                        var path = Path.Combine("", Directory.GetCurrentDirectory() + "\\Images\\" + newfilename);
                        using (var stream = new FileStream(path, FileMode.Create))
                        {
                            file.CopyTo(stream);
                        }
                        value.imagepath = path;
                        
                        value.InsertedOn = DateTime.Now;
                        user_Id = User.Identity.GetUserId<string>().Normalize();
                        await _repository.Insert(value, user_Id);
                    }
                    return new DeptResponse
                    {
                        Message = "File Uploaded Successfully",
                        IsSuccess = true
                    };
                }
                else
                {
                    return new DeptResponse
                    {
                        Message = "File not uploaded",
                        IsSuccess = false
                    };
                }
            }
            catch (Exception ex)
            {
                return new DeptResponse
                {
                    Message = ex.Message,
                    IsSuccess = false
                };
            }
        }
        //[HttpGet]
        //public ActionResult<List<ImageUpload>> GetImageUpload()
        //{
        //    var result = dbContext.ImageUploads.ToList();
        //    return result;
        //}
    }
}