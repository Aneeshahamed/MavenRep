﻿using Authenticate_With_Latest_version.Models;
using Authenticate_With_Latest_version.Models.Pagination;
using Authenticate_With_Latest_version.Response;
using Authenticate_With_Latest_version.Services;
using Microsoft.AspNet.Identity;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Authenticate_With_Latest_version.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class StudentController : ControllerBase
    {
        private readonly StudentService _repository;
        private string user_Id;
        public StudentController(StudentService repository)
        {
            this._repository = repository ?? throw new ArgumentNullException(nameof(repository));
        }

        // GET api/values
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Student>>> Get()
        {
            user_Id = User.Identity.GetUserId<string>().Normalize();
            return await _repository.GetAll(user_Id); 
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Student>> Get(int id)
        {
            user_Id = User.Identity.GetUserId<string>().Normalize();
            var response = await _repository.GetById(id, user_Id);
            if (response == null)
            {
                return NotFound();
            }
            return response;
        }

        // POST api/values
        [HttpPost]
        public async Task<DeptResponse> Post([FromBody] Student value)
        {
            user_Id = User.Identity.GetUserId<string>().Normalize();
            return await _repository.Insert(value, user_Id);
        }

        // PUT api/values/5
        [HttpPut]
        public async Task<DeptResponse> Put([FromBody] Student value)
        {
            user_Id = User.Identity.GetUserId<string>().Normalize();
            return await _repository.Update(value, user_Id);
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public async Task Delete(int id)
        {
            user_Id = User.Identity.GetUserId<string>().Normalize();
            await _repository.DeleteById(id);
        }
    }
}
