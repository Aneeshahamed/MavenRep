﻿using Authenticate_With_Latest_version.Models;
using Authenticate_With_Latest_version.Response;
using Authenticate_With_Latest_version.Services;
using Microsoft.AspNet.Identity;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System.Data;
using System.Security.Claims;

namespace Authenticate_With_Latest_version.Controllers
{
    [ApiController]
    [Authorize]
    public class DepartmentController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        private readonly Microsoft.AspNetCore.Identity.UserManager<IdentityUser> userManager;
        private readonly IUserList _user;
        private SqlConnection con;
        public DepartmentController(IConfiguration configuration, IUserList user)
        {
            _configuration = configuration;
            _user = user;
        }

        private void connection()
        {
            string constr = _configuration.GetConnectionString("DefaultConnection");
            con = new SqlConnection(constr);
        }

        [Microsoft.AspNetCore.Mvc.Route("api/{controller}/{action}")]
        [HttpGet]
        public IActionResult GetAllDetails()
        {
            var claimsIdentity = (ClaimsIdentity)this.User.Identity;
            var claim = claimsIdentity.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier);
            var userId = claim.Value;
            string user_Id = User.Identity.GetUserId<string>().Normalize();

            connection();
            con.Open();
            SqlCommand com = new SqlCommand("exec Department1", con);
            SqlDataAdapter sd = new SqlDataAdapter(com);
            DataTable dt = new DataTable();
            sd.Fill(dt);
            con.Close();
            return Ok(sd);

        }
        [Microsoft.AspNetCore.Mvc.Route("api/{controller}/{action}")]
        [HttpPost]
        public IActionResult create(Department dep)
        {
            string query = @"insert into dbo.Department values(@DepartmentName)";
            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("DefaultConnection");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                    myCommand.Parameters.AddWithValue("@DepartmentName", dep.DepartmentName);
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);
                    myReader.Close();
                    myCon.Close();
                }
            }
            return CreatedAtAction(nameof(create), new DeptResponse { Message = "Success" });
        }

        [Microsoft.AspNetCore.Mvc.Route("api/{controller}/{action}")]
        [HttpPut]
        public IActionResult update(Department dep)
        {
            string query = @"update dbo.Department set DepartmentName=@DepartmentName where DepartmentId=@DepartmentId";
            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("DefaultConnection");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                    myCommand.Parameters.AddWithValue("@DepartmentId", dep.DepartmentId);
                    myCommand.Parameters.AddWithValue("@DepartmentName", dep.DepartmentName);
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);
                    myReader.Close();
                    myCon.Close();
                }
            }
            return CreatedAtAction(nameof(update), new DeptResponse { Message = "Success" });
        }

        [Microsoft.AspNetCore.Mvc.Route("api/{controller}/{action}/{id}")]
        [HttpDelete]
        public IActionResult DeleteMethod(int id)
        {
            string query = @"delete from dbo.Department where DepartmentId=@DepartmentId";
            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("DefaultConnection");
            SqlDataReader myReader;
            using (SqlConnection myCon = new SqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myCon))
                {
                    myCommand.Parameters.AddWithValue("@DepartmentId", id);
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);
                    myReader.Close();
                    myCon.Close();
                }
            }
            return CreatedAtAction(nameof(DeleteMethod), new DeptResponse { Message = "Deleted Successfully" });
        }
    }
}