﻿using Microsoft.AspNetCore.Identity;

namespace Authenticate_With_Latest_version.Models
{
    public class User : IdentityUser
    {
        public string emailId { get; set; }
        public string provider { get; set; }
        public string key { get; set; }

    }
}
