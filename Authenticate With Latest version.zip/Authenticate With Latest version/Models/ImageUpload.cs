﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Authenticate_With_Latest_version.Models
{
    public class ImageUpload
    {
        public int Id { get; set; }
        public string imagepath { get; set; }
        public DateTime InsertedOn { get; set; }
    }
}
