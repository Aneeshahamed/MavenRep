﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Authenticate_With_Latest_version.Models.Pagination
{
    public class Page
    {
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
    }
}
