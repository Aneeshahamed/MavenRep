﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Authenticate_With_Latest_version.Models
{
    public class DeleteUserModel
    {
        public string id { get; set; }
    }
}
