﻿using Microsoft.AspNetCore.Identity;

namespace Authenticate_With_Latest_version.Authentication
{
    public class ApplicationUser : IdentityUser
    {

    }
}
