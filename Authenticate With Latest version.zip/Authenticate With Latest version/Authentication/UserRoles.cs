﻿namespace Authenticate_With_Latest_version.Authentication
{
    public class UserRoles
    {
        public const string User = "User";
        public const string Admin = "Admin";
    }
}
