﻿using Microsoft.AspNetCore.Http;
using System.Security.Claims;

namespace Authenticate_With_Latest_version.Services
{
    public class UserList : IUserList
    {
        private readonly IHttpContextAccessor _httpContext;

        public UserList(IHttpContextAccessor httpContextAccessor)
        {
            _httpContext = httpContextAccessor;
        }

        public string GetUserId()
        {

            return _httpContext.HttpContext.User?.FindFirstValue(ClaimTypes.Name);
        }

        public bool IsAuthenticated()
        {
            return _httpContext.HttpContext.User.Identity.IsAuthenticated;
        }
    }
}
