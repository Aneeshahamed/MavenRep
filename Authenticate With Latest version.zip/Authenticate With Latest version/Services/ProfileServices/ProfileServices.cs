﻿using Authenticate_With_Latest_version.Models;
using Authenticate_With_Latest_version.Response;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System;
using System.Threading.Tasks;

namespace Authenticate_With_Latest_version.Services.ProfileServices
{
    public class ProfileServices
    {
        private readonly string _connectionString;
        public ProfileServices(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");

        }

        public async Task<DeptResponse> Insert(ImageUpload value, string userId)
        {
            using (SqlConnection sql = new SqlConnection(_connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("InsertImage", sql))
                {
                    await sql.OpenAsync();
                    try
                    {
                        cmd.CommandType = System.Data.CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@ImagePath", value.imagepath.ToString()));
                        cmd.Parameters.Add(new SqlParameter("@InsertedOn", value.InsertedOn));
                        cmd.Parameters.Add(new SqlParameter("@UserId", userId));

                        int i = await cmd.ExecuteNonQueryAsync();
                        await sql.CloseAsync();

                        if (i < 0)
                        {
                            return new DeptResponse
                            {
                                Message = "Failed",
                                IsSuccess = false
                            };
                        }
                        else
                        {
                            return new DeptResponse
                            {
                                Message = "File uploaded Successfully",
                                IsSuccess = true
                            };
                        }
                        
                    }
                    catch (Exception e)
                    {
                        await sql.CloseAsync();
                        return new DeptResponse
                        {
                            Message = e.Message,
                            IsSuccess = false
                        };
                    }

                }
            }
        }
    }
}
