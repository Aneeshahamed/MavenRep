﻿using Authenticate_With_Latest_version.Models.Pagination;
using System.Threading.Tasks;

namespace Authenticate_With_Latest_version.Services.Pagination
{
    public interface IMockData
    {
        Task<int> GetMockDataCountAsync();
        Task<PagedList<MockDataDto>> GetMockDataPagedAsync(Page page);
    }
}
