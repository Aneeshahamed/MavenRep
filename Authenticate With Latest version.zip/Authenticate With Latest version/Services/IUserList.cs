﻿namespace Authenticate_With_Latest_version.Services
{
    public interface IUserList
    {
        string GetUserId();
    }
}
