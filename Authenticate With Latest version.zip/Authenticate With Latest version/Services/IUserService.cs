﻿using Authenticate_With_Latest_version.Authentication;
using Authenticate_With_Latest_version.Models;
using Authenticate_With_Latest_version.Response;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.WebUtilities;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace Authenticate_With_Latest_version.Services
{
    public interface IUserService
    {

        Task<UserManagerResponse> RegisterUserAsync(RegisterViewModel model);

        Task<UserManagerResponse> RegisterAdminUserAsync(RegisterViewModel model);

        Task<UserManagerResponse> LoginUserAsync(LoginViewModel model);

        Task<UserManagerResponse> ConfirmEmailAsync(string userId, string token);

        Task<UserManagerResponse> ForgetPasswordAsync(string email);

        Task<UserManagerResponse> ResetPasswordAsync(ResetPasswordViewModel model);
        Task<UserManagerResponse> DeleteUserAsync(DeleteUserModel id);
        Task<UserManagerResponse> GetOrCreateExternalLoginUser(User model);
    }

    public class UserService : IUserService
    {
        private UserManager<IdentityUser> _userManger;
        private readonly RoleManager<IdentityRole> roleManager;
        private IConfiguration _configuration;
        private IMailService _mailService;

        public UserService(UserManager<IdentityUser> userManager, IConfiguration configuration, IMailService mailService, RoleManager<IdentityRole> roleManager)
        {
            _userManger = userManager;
            _configuration = configuration;
            _mailService = mailService;
            this.roleManager = roleManager;
        }

        public async Task<UserManagerResponse> RegisterUserAsync(RegisterViewModel model)
        {
            var userExist = await _userManger.FindByNameAsync(model.Email);
            if (userExist != null)
            {
                return new UserManagerResponse
                {
                    Message = "User already exist",
                    IsSuccess = false,
                };
            }
            if (model == null)
                throw new NullReferenceException("Reigster Model is null");

            if (model.Password != model.ConfirmPassword)
                return new UserManagerResponse
                {
                    Message = "Confirm password doesn't match the password",
                    IsSuccess = false,
                };

            var identityUser = new IdentityUser
            {
                Email = model.Email,
                UserName = model.Email,
            };

            var result = await _userManger.CreateAsync(identityUser, model.Password);

            if (result.Succeeded)
            {
                _ = SendMailServiceAsync(identityUser);

                return new UserManagerResponse
                {
                    Message = "User created successfully!",
                    IsSuccess = true,
                };
            }

            return new UserManagerResponse
            {
                Message = "User did not create",
                IsSuccess = false,
                Errors = result.Errors.Select(e => e.Description)
            };

        }

        private async Task SendMailServiceAsync(IdentityUser identityUser)
        {
            var confirmEmailToken = await _userManger.GenerateEmailConfirmationTokenAsync(identityUser);

            var encodedEmailToken = Encoding.UTF8.GetBytes(confirmEmailToken);
            var validEmailToken = WebEncoders.Base64UrlEncode(encodedEmailToken);

            string url = $"{_configuration["AppUrl"]}/api/auth/confirmemail?userid={identityUser.Id}&token={validEmailToken}";

            await _mailService.SendEmailAsync(identityUser.Email, "Confirm your email", $"<h1>Welcome to Auth Demo</h1>" +
                $"<p>Please confirm your email by <a href='{url}'>Clicking here</a></p>");
        }

        public async Task<UserManagerResponse> RegisterAdminUserAsync(RegisterViewModel model)
        {
            var userExist = await _userManger.FindByNameAsync(model.Email);
            if (userExist != null)
            {
                return new UserManagerResponse
                {
                    Message = "User already exist",
                    IsSuccess = false,
                };
            }
            bool x = await roleManager.RoleExistsAsync("Admin");
            if (!x)
            {
                // first we create Admin rool    
                var role = new IdentityRole();
                role.Name = "Admin";
                await roleManager.CreateAsync(role);
                var admin = new IdentityUser
                {
                    Email = model.Email,
                    UserName = model.Email,
                };
                IdentityResult chkUser_admin = await _userManger.CreateAsync(admin, model.Password);
                //Add default User to Role Admin    
                if (chkUser_admin.Succeeded)
                {
                    var result1 = await _userManger.AddToRoleAsync(admin, "Admin");
                    _ = SendMailServiceAsync(admin);
                    return new UserManagerResponse
                    {
                        Message = "Admin User created Successfully",
                        IsSuccess = true,
                        Role = "Admin"
                    };
                }
            }
            var admin1 = new IdentityUser
            {
                Email = model.Email,
                UserName = model.Email,
            };
            await _userManger.CreateAsync(admin1, model.Password);
            var result = await _userManger.AddToRoleAsync(admin1, "Admin");
            if (!result.Succeeded)
            {
                return new UserManagerResponse
                {
                    Message = "Unable to Assign the user as Admin",
                    IsSuccess = false,
                };

            }
            _ = SendMailServiceAsync(admin1);
            return new UserManagerResponse
            {
                Message = "Admin User created Successfully",
                IsSuccess = true,
                Role = "Admin"
            };

        }

        public async Task<UserManagerResponse> LoginUserAsync(LoginViewModel model)
        {
            var user = await _userManger.FindByEmailAsync(model.Email);

            if (user == null)
            {
                return new UserManagerResponse
                {
                    Message = "Email Id does not exist",
                    IsSuccess = false,
                };
            }

            var result = await _userManger.CheckPasswordAsync(user, model.Password);

            if (!result)
                return new UserManagerResponse
                {
                    Message = "Invalid password",
                    IsSuccess = false,
                };

            var claims = new List<Claim>
            {
                //new Claim(JwtRegisteredClaimNames.Sub, user.UserName),
                //new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                //new Claim(ClaimTypes.NameIdentifier, user.Id),

                new Claim("Email", model.Email),
                new Claim(ClaimTypes.NameIdentifier, user.Id),
            };

            // Get User roles and add them to claims
            var roles = await _userManger.GetRolesAsync(user);
            AddRolesToClaims(claims, roles);

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["AuthSettings:Key"]));

            if (user != null && await _userManger.CheckPasswordAsync(user, model.Password))
            {
                if (user.EmailConfirmed)
                {
                    var token = new JwtSecurityToken(
                        issuer: _configuration["AuthSettings:Issuer"],
                        audience: _configuration["AuthSettings:Audience"],
                        claims: claims,
                        expires: DateTime.Now.AddHours(2),
                        signingCredentials: new SigningCredentials(key, SecurityAlgorithms.HmacSha256));

                    string tokenAsString = new JwtSecurityTokenHandler().WriteToken(token);
                    return new UserManagerResponse
                    {
                        Message = tokenAsString,
                        IsSuccess = true,
                        ExpireDate = token.ValidTo.AddHours(2),
                        EmailConfirmed = user.EmailConfirmed
                    };
                }
            }
            return new UserManagerResponse
            {
                Message = "Please check your inbox/spam and verify your Email address",
                IsSuccess = false,
            };

        }

        private void AddRolesToClaims(List<Claim> claims, IEnumerable<string> roles)
        {
            foreach (var role in roles)
            {
                var roleClaim = new Claim(ClaimTypes.Role, role);
                claims.Add(roleClaim);
            }
        }

        public async Task<UserManagerResponse> ConfirmEmailAsync(string userId, string token)
        {
            var user = await _userManger.FindByIdAsync(userId);

            if (user == null)
                return new UserManagerResponse
                {
                    IsSuccess = false,
                    Message = "User not found"
                };

            var decodedToken = WebEncoders.Base64UrlDecode(token);
            string normalToken = Encoding.UTF8.GetString(decodedToken);

            var result = await _userManger.ConfirmEmailAsync(user, normalToken);

            if (result.Succeeded)
                return new UserManagerResponse
                {
                    Message = "Email confirmed successfully!",
                    IsSuccess = true,
                };

            return new UserManagerResponse
            {
                IsSuccess = false,
                Message = normalToken,
                Errors = result.Errors.Select(e => e.Description)
            };
        }

        public async Task<UserManagerResponse> ForgetPasswordAsync(string email)
        {
            var user = await _userManger.FindByEmailAsync(email);
            if (user == null)
            {
                return new UserManagerResponse
                {
                    IsSuccess = false,
                    Message = "No user associated with email",
                };
            }
                
            if (user.EmailConfirmed)
            {
                var token = await _userManger.GeneratePasswordResetTokenAsync(user);
                var encodedToken = Encoding.UTF8.GetBytes(token);
                var validToken = WebEncoders.Base64UrlEncode(encodedToken);

                string url = $"{_configuration["AppUrl"]}/ResetPassword?email={email}&token={validToken}";

                await _mailService.SendEmailAsync(email, "Reset Password", "<h1>Follow the instructions to reset your password</h1>" +
                    $"<p>To reset your password <a href='{url}'>Click here</a></p>");

                return new UserManagerResponse
                {
                    IsSuccess = true,
                    Message = "Reset password URL has been sent to the email successfully!"
                };
            }
            return new UserManagerResponse
            {
                IsSuccess = false,
                Message = "Email Id has not been verified"
            };

        }

        public async Task<UserManagerResponse> ResetPasswordAsync(ResetPasswordViewModel model)
        {
            var user = await _userManger.FindByEmailAsync(model.Email);
            if (user == null)
                return new UserManagerResponse
                {
                    IsSuccess = false,
                    Message = "No user associated with email",
                };

            if (model.NewPassword != model.ConfirmPassword)
                return new UserManagerResponse
                {
                    IsSuccess = false,
                    Message = "Password doesn't match its confirmation",
                };

            var decodedToken = WebEncoders.Base64UrlDecode(model.Token);
            string normalToken = Encoding.UTF8.GetString(decodedToken);

            var result = await _userManger.ResetPasswordAsync(user, normalToken, model.NewPassword);

            if (result.Succeeded)

                return new UserManagerResponse
                {
                    Message = "Password has been reset successfully!",
                    IsSuccess = true,
                };

            return new UserManagerResponse
            {
                Message = "Something went wrong",
                IsSuccess = false,
                Errors = result.Errors.Select(e => e.Description),
            };
        }

        public async Task<UserManagerResponse> DeleteUserAsync(DeleteUserModel id)
        {
            var user = await _userManger.FindByEmailAsync(id.id);

            if (user == null)
            {
                return new UserManagerResponse
                {
                    Message = "user not found",
                    IsSuccess = false,
                };
            }

            var result = await _userManger.DeleteAsync(user);
            if (!result.Succeeded)
            {
                return new UserManagerResponse
                {
                    Message = "user not deleted",
                    IsSuccess = false,
                };
            }
            return new UserManagerResponse
            {
                Message = "user deleted Successfully",
                IsSuccess = true,
            };
        }

        public async Task<UserManagerResponse> GetOrCreateExternalLoginUser(User model)
        {
            var user = await _userManger.FindByLoginAsync(model.provider, model.key);
            if (user != null)
            {
                var claims = new List<Claim>
                {
                    new Claim("Email", model.emailId),
                    new Claim(ClaimTypes.NameIdentifier, user.Id),
                };
                var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["AuthSettings:Key"]));
                var token = new JwtSecurityToken(
                        issuer: _configuration["AuthSettings:Issuer"],
                        audience: _configuration["AuthSettings:Audience"],
                        claims: claims,
                        expires: DateTime.Now.AddHours(2),
                        signingCredentials: new SigningCredentials(key, SecurityAlgorithms.HmacSha256));

                string tokenAsString = new JwtSecurityTokenHandler().WriteToken(token);

                return new UserManagerResponse
                {
                    Message = user.Email+" Already exist",
                    IsSuccess = false,
                    EmailConfirmed = true,
                    token = tokenAsString
                };
            }
            user = await _userManger.FindByEmailAsync(model.emailId);
            if (user == null)
            {
                user = new User
                {
                    Email = model.emailId,
                    UserName = model.emailId,
                };
                await _userManger.CreateAsync(user);
            }

            var info = new UserLoginInfo(model.provider, model.key, model.provider.ToUpperInvariant());
            var result = await _userManger.AddLoginAsync(user, info);

            if (result.Succeeded)
            {
                var claims = new List<Claim>
                {
                    new Claim("Email", model.emailId),
                    new Claim(ClaimTypes.NameIdentifier, user.Id),
                };
                var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["AuthSettings:Key"]));
                var token = new JwtSecurityToken(
                        issuer: _configuration["AuthSettings:Issuer"],
                        audience: _configuration["AuthSettings:Audience"],
                        claims: claims,
                        expires: DateTime.Now.AddHours(2),
                        signingCredentials: new SigningCredentials(key, SecurityAlgorithms.HmacSha256));

                string tokenAsString = new JwtSecurityTokenHandler().WriteToken(token);
                return new UserManagerResponse
                {
                    Message = user.Email + " Already exist",
                    IsSuccess = false,
                    EmailConfirmed = true,
                    token = tokenAsString
                };
            }
            return new UserManagerResponse
            {
                Message = user.Email + " issue found",
                IsSuccess = false,
                EmailConfirmed = true,
                Errors = result.Errors.Select(e => e.Description),
            };

        }

    }
}