﻿using Authenticate_With_Latest_version.Models;
using Authenticate_With_Latest_version.Response;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Authenticate_With_Latest_version.Services
{
    public class StudentService
    {
        private readonly string _connectionString;
        public StudentService(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");

        }

        public async Task<List<Student>> GetAll(string userId)
        {
            using (SqlConnection sql = new SqlConnection(_connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("GetAllStudents", sql))
                {
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@Id", userId));
                    var response = new List<Student>();
                    await sql.OpenAsync();
                    using (var reader = await cmd.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            response.Add(MapToValue(reader));
                        }
                    }
                    await sql.CloseAsync();
                    return response;
                }
            }
        }

        private Student MapToValue(SqlDataReader reader)
        {
            return new Student()
            {
                StudentId = (int)reader["StudentId"],
                Id = reader["Id"].ToString(),
                Age = (int)reader["Age"],
                StudentName = reader["StudentName"].ToString()
            };
        }

        public async Task<Student> GetById(int Id, string userId)
        {
            using (SqlConnection sql = new SqlConnection(_connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("GetStudentsById", sql))
                {
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@StudentId", Id));
                    cmd.Parameters.Add(new SqlParameter("@Id", userId));
                    Student response = null;
                    await sql.OpenAsync();

                    using (var reader = await cmd.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            response = MapToValue(reader);
                        }
                    }
                    await sql.CloseAsync();
                    return response;
                }
            }
        }

        public async Task<DeptResponse> Insert(Student value, string userId)
        {
            using (SqlConnection sql = new SqlConnection(_connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("InsertStudentRecord", sql))
                {
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@StudentName", value.StudentName.ToString()));
                    cmd.Parameters.Add(new SqlParameter("@Age", value.Age));
                    cmd.Parameters.Add(new SqlParameter("@Id", userId.ToString()));
                    await sql.OpenAsync();
                    await cmd.ExecuteNonQueryAsync();
                    await sql.CloseAsync();
                    return new DeptResponse
                    {
                        Message = "Success",
                        IsSuccess = true
                    };
                }
            }
        }

        public async Task<DeptResponse> Update(Student value, string userId)
        {
            using (SqlConnection sql = new SqlConnection(_connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("UpdateStudentRecord", sql))
                {
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@StudentId", value.StudentId));
                    cmd.Parameters.Add(new SqlParameter("@StudentName", value.StudentName));
                    cmd.Parameters.Add(new SqlParameter("@Age", value.Age));
                    cmd.Parameters.Add(new SqlParameter("@Id", userId));
                    await sql.OpenAsync();
                    await cmd.ExecuteNonQueryAsync();
                    await sql.CloseAsync();
                    return new DeptResponse
                    {
                        Message = "Updated Recorded Successfully",
                        IsSuccess = true
                    };
                }
            }
        }

        public async Task DeleteById(int StudentId)
        {
            using (SqlConnection sql = new SqlConnection(_connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("DeleteValue", sql))
                {
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@Id", StudentId));
                    await sql.OpenAsync();
                    await cmd.ExecuteNonQueryAsync();
                    await sql.CloseAsync();
                    return;
                }
            }
        }
    }
}
