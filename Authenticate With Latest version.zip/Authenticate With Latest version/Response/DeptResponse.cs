﻿namespace Authenticate_With_Latest_version.Response
{
    public class DeptResponse
    {
        public string Message { get; set; }
        public bool IsSuccess { get; set; }
    }
}
